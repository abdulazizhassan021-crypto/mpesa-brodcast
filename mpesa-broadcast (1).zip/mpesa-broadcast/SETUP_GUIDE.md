# M-Pesa SMS Broadcast — Setup Guide

## What You Built
A real-time web app where:
- M-Pesa SMS arrives on master phone
- MacroDroid reads it automatically
- All attendants see it instantly on their phone browsers

---

## STEP 1 — Deploy to Render.com (Free Hosting)

1. Go to https://render.com and create a free account
2. Click **"New +"** → **"Web Service"**
3. Connect your GitHub account (or use "Public Git Repo")
4. Upload this project folder OR use: https://github.com/your-repo
5. Set these settings:
   - **Name**: mpesa-broadcast
   - **Runtime**: Node
   - **Build Command**: `npm install`
   - **Start Command**: `node server.js`
6. Under **Environment Variables**, add:
   - Key: `MASTER_PIN` → Value: (your secret PIN e.g. `7842`)
7. Click **Deploy**
8. You get a URL like: `https://mpesa-broadcast.onrender.com`

---

## STEP 2 — Share the Attendant Link

Send this link to all 3 attendants via WhatsApp:
```
https://mpesa-broadcast.onrender.com
```
They bookmark it on their phone browser. Done. ✅

---

## STEP 3 — Set Up MacroDroid (Auto SMS Forwarding)

This makes it 100% automatic — no manual pasting needed.

### Install MacroDroid
1. Open Google Play Store on master phone
2. Search **MacroDroid** → Install (free)
3. Open it → allow all permissions (especially SMS)

### Create the Macro

**TRIGGER:**
- Tap "Add Macro" → "Add Trigger"
- Choose: **SMS / MMS Received**
- Filter: Sender contains `MPESA` (or check your sender name)
- Tap OK

**ACTION:**
- Tap "Add Action"
- Choose: **HTTP Request**
- URL: `https://mpesa-broadcast.onrender.com/api/sms`
- Method: **POST**
- Content Type: **application/json**
- Body:
```json
{
  "pin": "YOUR_PIN_HERE",
  "body": "[sms_body]",
  "sender": "[sms_sender]"
}
```
Replace `YOUR_PIN_HERE` with your actual PIN.
`[sms_body]` and `[sms_sender]` are MacroDroid magic variables — type them exactly.

- Tap OK → Name your macro "M-Pesa Broadcast" → Save → Enable ✅

---

## STEP 4 — Test It

1. Send KES 1 to the M-Pesa number
2. SMS arrives on master phone
3. MacroDroid fires automatically
4. All attendants see it on their screens within 2 seconds 🎉

---

## PIN Management

- Default PIN: set in Render environment variables as `MASTER_PIN`
- Change PIN: update the environment variable in Render dashboard → redeploy
- Master phone opens: `https://mpesa-broadcast.onrender.com/master.html`

---

## Troubleshooting

| Problem | Fix |
|---------|-----|
| MacroDroid not firing | Check SMS permissions → Settings → Apps → MacroDroid → Permissions |
| Attendants not seeing SMS | Check internet connection on their phones |
| App sleeping on Render | Free tier sleeps after 15 mins — upgrade to paid ($7/mo) or use UptimeRobot to ping it |
| Wrong sender name | Check the exact sender name of M-Pesa SMS on your master phone |

---

## Prevent App Sleeping (Free Fix)

Render free tier sleeps after 15 minutes of inactivity.
1. Go to https://uptimerobot.com (free account)
2. Add monitor → HTTP → URL: `https://mpesa-broadcast.onrender.com/api/messages`
3. Interval: every 5 minutes
4. This keeps your app always awake ✅
