const express = require('express');
const app = express();
const http = require('http').createServer(app);
const io = require('socket.io')(http, { cors: { origin: '*' } });

app.use(express.json());
app.use(express.static('public'));

const messages = [];
const MASTER_PIN = process.env.MASTER_PIN || '1234';

// MacroDroid hits this endpoint automatically when M-Pesa SMS arrives
app.post('/api/sms', (req, res) => {
  const { pin, body, sender } = req.body;
  if (pin !== MASTER_PIN) return res.status(401).json({ error: 'Invalid PIN' });
  if (!body) return res.status(400).json({ error: 'No SMS body' });

  const msg = {
    id: Date.now(),
    body,
    sender: sender || 'MPESA',
    time: new Date().toISOString(),
    amount: extractAmount(body),
    ref: extractRef(body)
  };

  messages.unshift(msg);
  if (messages.length > 100) messages.pop(); // keep last 100

  io.emit('new_sms', msg); // broadcast to ALL attendants instantly
  res.json({ success: true, msg });
});

// Attendants load all messages on page open
app.get('/api/messages', (req, res) => {
  res.json(messages);
});

// PIN verify endpoint
app.post('/api/verify', (req, res) => {
  res.json({ ok: req.body.pin === MASTER_PIN });
});

function extractAmount(txt) {
  const m = txt.match(/KES\s?([\d,]+\.?\d*)/i);
  return m ? m[1] : null;
}

function extractRef(txt) {
  const m = txt.match(/^([A-Z0-9]{10})/);
  return m ? m[1] : null;
}

io.on('connection', (socket) => {
  console.log('Attendant connected:', socket.id);
  socket.on('disconnect', () => console.log('Attendant disconnected:', socket.id));
});

const PORT = process.env.PORT || 3000;
http.listen(PORT, () => console.log(`M-Pesa Broadcast running on port ${PORT}`));
